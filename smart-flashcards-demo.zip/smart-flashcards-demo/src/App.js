import SmartFlashcardGenerator from "./SmartFlashcardGenerator";

function App() {
  return <SmartFlashcardGenerator />;
}

export default App;
