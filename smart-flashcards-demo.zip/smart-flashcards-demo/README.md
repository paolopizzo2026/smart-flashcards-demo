# Smart Flashcard Generator

Demo di progetto React per creare flashcard interattive.  
Pronto per il deploy su Render come Static Site.

## Installazione

```bash
npm install
npm start
